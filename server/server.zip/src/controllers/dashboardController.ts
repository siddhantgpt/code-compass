import { Request, Response } from "express";
import { Topic } from "../models/Topic";

export const getDashboardData = async (
  req: Request,
  res: Response
): Promise<void> => {
  try {
    const userId = req.user?.id;
    if (!userId) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }

    const totalTopics = await Topic.countDocuments({ userId });
    const topicsMastered = await Topic.countDocuments({
      userId,
      mastered: true,
    });
    const weeklyActivity = 5;
    const weeklyGoalPercentage = 80;
    const currentStreak = 3;
    const personalBest = 7;

    const recentTopics = await Topic.find({ userId })
      .sort({ updatedAt: -1 })
      .limit(5);

    res.json({
      totalTopics,
      topicsMastered,
      weeklyActivity,
      weeklyGoalPercentage,
      currentStreak,
      personalBest,
      continueLearning: recentTopics[0]
        ? {
            topic: recentTopics[0].title,
            completion: recentTopics[0].completion,
          }
        : null,
      recentTopics: recentTopics.map((topic) => ({
        title: topic.title,
        lastAccessed: topic.updatedAt,
      })),
    });
  } catch (error) {
    res.status(500).json({ message: "Server error" });
  }
};
