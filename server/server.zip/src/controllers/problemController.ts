import { Request, Response } from "express";
import Problem from "../models/Problem";

export const getAllProblems = async (req: Request, res: Response) => {
  try {
    const problems = await Problem.find();
    res.status(200).json(problems);
  } catch (error) {
    console.error("Error fetching problems:", error);
    res.status(500).json({ message: "Server error" });
  }
};
