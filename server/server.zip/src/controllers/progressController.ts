import { Request, Response } from 'express';
import { User } from '../models/User';

export const getProgress = async (req: Request, res: Response): Promise<void> => {
  try {
    if (!req.user?.id) {
      res.status(401).json({ message: 'Unauthorized' });
      return;
    }
    const user = await User.findById(req.user.id);
    if (!user) {
      res.status(404).json({ message: 'User not found' });
      return;
    }
    res.status(200).json({ completedProblems: user.completedProblems });
  } catch (error) {
    console.error('Error fetching progress:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const updateProgress = async (req: Request, res: Response): Promise<void> => {
  try {
    if (!req.user?.id) {
      res.status(401).json({ message: 'Unauthorized' });
      return;
    }
    const user = await User.findById(req.user.id);
    if (!user) {
      res.status(404).json({ message: 'User not found' });
      return;
    }

    const { problemId } = req.body;
    const isCompleted = user.completedProblems.includes(problemId);

    if (isCompleted) {
      user.completedProblems = user.completedProblems.filter(
        (id: any) => id.toString() !== problemId
      );
    } else {
      user.completedProblems.push(problemId);
    }

    await user.save();
    res.status(200).json({ completedProblems: user.completedProblems });
  } catch (error) {
    console.error('Error updating progress:', error);
    res.status(500).json({ message: 'Server error' });
  }
};
