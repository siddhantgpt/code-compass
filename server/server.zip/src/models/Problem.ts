import { Schema, model, Document } from "mongoose";

export interface IProblem extends Document {
  title: string;
  topic: string;
  subTopic: string;
  youtubeLink: string;
  leetcodeLink: string;
  articleLink: string;
  difficulty: "Easy" | "Medium" | "Hard";
}

const ProblemSchema = new Schema<IProblem>({
  title: { type: String, required: true },
  topic: { type: String, required: true },
  subTopic: { type: String, required: true },
  youtubeLink: { type: String, required: true },
  leetcodeLink: { type: String, required: true },
  articleLink: { type: String, required: true },
  difficulty: {
    type: String,
    enum: ["Easy", "Medium", "Hard"],
    required: true,
  },
});

export default model<IProblem>("Problem", ProblemSchema);
