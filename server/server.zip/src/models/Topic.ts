import mongoose, { Document, Schema, Types } from "mongoose";

export interface ITopic extends Document {
  userId: Types.ObjectId;
  title: string;
  mastered: boolean;
  completion: number;
  updatedAt?: Date;
}

const topicSchema = new Schema<ITopic>(
  {
    userId: { type: Schema.Types.ObjectId, required: true, ref: "User" },
    title: { type: String, required: true },
    mastered: { type: Boolean, default: false },
    completion: { type: Number, default: 0 },
  },
  { timestamps: true }
);

export const Topic = mongoose.model<ITopic>("Topic", topicSchema);