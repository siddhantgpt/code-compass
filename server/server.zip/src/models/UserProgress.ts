import mongoose, { Schema, Document } from "mongoose";

interface IUserProgress extends Document {
  userId: string;
  topicsMastered: number;
  totalTopics: number;
  weeklyActivity: number;
  weeklyGoalPercentage: number;
  currentStreak: number;
  personalBest: number;
  continueLearning: {
    topic: string;
    completion: number;
    lastSubtopic: string;
  };
}

const UserProgressSchema: Schema = new Schema({
  userId: { type: String, required: true },
  topicsMastered: { type: Number, required: true },
  totalTopics: { type: Number, required: true },
  weeklyActivity: { type: Number, required: true },
  weeklyGoalPercentage: { type: Number, required: true },
  currentStreak: { type: Number, required: true },
  personalBest: { type: Number, required: true },
  continueLearning: {
    topic: { type: String, required: true },
    completion: { type: Number, required: true },
    lastSubtopic: { type: String, required: true },
  },
});

export const UserProgress = mongoose.model<IUserProgress>(
  "UserProgress",
  UserProgressSchema
);
