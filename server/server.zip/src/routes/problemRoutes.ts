import { Router } from 'express';
import { getAllProblems } from '../controllers/problemController';
import { getProgress, updateProgress } from '../controllers/progressController';
import { authMiddleware } from '../middlewares/authMiddleware';

const router = Router();

// Problems
router.get('/', authMiddleware, getAllProblems);

// Progress
router.get('/progress', authMiddleware, getProgress);
router.post('/progress', authMiddleware, updateProgress);

export default router;